module.exports = {
  extends: ["next/core-web-vitals"]
};